# cricket-html-template


## Home Page Template
![alt text](screenshots/home.png)
## Widgets for Cricket Score and Stats
![alt text](screenshots/widgets.png)
## Full Scorecard
![alt text](screenshots/main.png)

## Cricket API from Roanuz

These HTML templates are designed to use with Roanuz Cricket API https://www.cricketapi.com/. For any support, please contact support@cricketapi.com
